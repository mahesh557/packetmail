use Test::More 'no_plan';
use strict;
use warnings;
use lib 'lib';
use Clipboard;
1;
